# Sadiq

The code starts by importing the openai library. If you have not already installed openAI library, you can do this by running the following command in the terminal: 'pip install openai'

Next, it sets up an environment variable called OPENAI_Key with the API key from OpenAI.For this you need to generate an API secret key using the following link: https://platform.openai.com/account/api-keys. Insert this key in the variable named 'API_KEY'.

Finally, just run and debug the code and a prompt will appear at the terminal saying: "AI:Hello. If you dont have any more questions, type exit.\n You:"

You can ask anything to the chatbot and when you are done, type 'exit' to terminate the code.
